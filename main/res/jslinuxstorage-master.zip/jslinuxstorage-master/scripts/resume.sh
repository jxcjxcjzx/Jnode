#!/bin/sh
./mkdevnode.sh
./mount.sh

#!/bin/sh
echo "Umounting /dev/sb1"
umount /dev/sb1

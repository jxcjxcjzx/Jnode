#!/bin/sh
echo "Creating ext2 filesystem on /dev/sb1"
mkfs.ext2 /dev/sb1

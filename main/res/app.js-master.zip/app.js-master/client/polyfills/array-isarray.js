
Array.isArray = function(a) {
    return a instanceof Array;
};

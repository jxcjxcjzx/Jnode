#include <stdio.h>

int main(int argc, char *argv[]) {
    printf("All is well\n");

    return 0;
}

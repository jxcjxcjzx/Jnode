# Magic
Sufficiently advanced technology, beyond the understanding of the observer producing a sense of wonder.

Hello, I am random noise in the middle of this beautiful Glossary. (Really astonishing !)

# PHP
An atrocious language, invented for the sole purpose of inflicting pain and suffering amongst the proframming wizards of this world.

# Clojure
Lisp re-invented for hipsters.

# Go
Go Go Google [Wow](https://www.google.com)

Fantastic, I love code too ! :

```py

def f(x):
    return x * 4

# Wow this is some really awesome code
# totally mind blowing
# but we don't care, it shouldn't be in our glossary !
print(f(9))
```

# Gitbook

Awesome project. Really amazing, I'm really at a loss for words ...

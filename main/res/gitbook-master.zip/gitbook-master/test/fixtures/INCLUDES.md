# Beautiful chapter

Here is a nice included snippet :

```c
{{ included.c }}
```

----

An exercise using includes

```c
{{ included.c }}

Remove this extra code at the end
```

```c
{{ included.c }}
```

```c
{{ included.c }}

This validation code is wrong but who cares ?
```

----

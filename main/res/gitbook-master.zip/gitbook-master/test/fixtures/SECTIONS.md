# Title

Some text

---

## NOT Exercise

Simple subsection NOT exercise

```
x = 1
```

What is this

```
y = [1, 2, 3]
```

```
z = {a: 1, b: 2}
```

---

## Exercise

Define a variable `x` equal to 10.

```js
var x =
```

```js
var x = 10;
```

```js
assert(x == 10);
```

```js
// This is context code available everywhere
// The user will be able to call magicFunc in his code
function magicFunc() {
    return 3;
}
```

---

## Another exercise

Bla bla bla ... This time with no `context` code.


```js
var x =
```

```js
var x = 10;
```

```js
assert(x == 10);
```

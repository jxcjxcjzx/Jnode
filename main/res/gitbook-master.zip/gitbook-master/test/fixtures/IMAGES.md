# Images Test

This is a test for images path calculation. It supposed this fiel is in a syntax/ folder

### #

[![Screen](./preview.png)](./preview.png)

### 2

[![Screen](../preview2.png)](./preview2.png)


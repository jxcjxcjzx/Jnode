## Wow such book

Some nice content here

---

A beautiful separator, but non an exercise or a quiz !

---

Some more beautiful text, because `this` book is awesome ...

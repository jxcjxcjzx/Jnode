# Nice course

Check out this source file [in C++](../src/something.cpp)

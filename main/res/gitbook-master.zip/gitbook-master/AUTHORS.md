Authors
=======

Also see https://github.com/GitbookIO/gitbook/graphs/contributors.
Names below are ordered by first contribution.

Author
------

- Samy Pessé <samypesse@gmail.com>
- Aaron O'Mullan <aaron.omullan@gmail.com>


Contributors
------------

- Nijiko Yonskai
- Herman Starikov

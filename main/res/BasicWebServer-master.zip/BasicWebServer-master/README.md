BasicWebServer
==============

A lean and mean web server implemented in C#

var config = {
  serialPort: '', //serial port ID goes here
  baudRate: '', //baudRate integer goes here
}

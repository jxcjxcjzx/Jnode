var sdl = module.exports = require('./build/Release/node_sdl.node');

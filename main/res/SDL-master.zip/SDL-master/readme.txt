SDL for Java v1.0

This library has no external dependencies.
SDL for Java required JRE 1.5 or higher.

See the tests in src/org/ikayzo/sdl/test and Tag Javadoc:
doc/org/ikayzo/sdl/Tag.html
for examples.

For more info see:
http://sdl.ikayzo.org/docs

Changes since beta 4:
- Changed identifier definition to allow periods (.)
- Fixed bug disallowing use of "$" in identifiers
- Fixed numerous documentation errors
- Various updates to documentation


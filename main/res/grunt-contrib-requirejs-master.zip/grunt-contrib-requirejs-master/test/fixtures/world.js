define(function(){return "world";});

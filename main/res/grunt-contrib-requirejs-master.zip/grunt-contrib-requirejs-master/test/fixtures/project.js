require(['hello', 'world'], function(hello, world) {
  console.log(hello,world);
});

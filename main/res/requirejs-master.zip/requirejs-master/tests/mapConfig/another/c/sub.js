define(['./dim'], function (dim) {
    return {
        name: 'another/c/sub',
        dimName: dim.name
    };
});

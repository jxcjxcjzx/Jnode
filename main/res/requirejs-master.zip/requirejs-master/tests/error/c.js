define(['a'], function (a) {
    return {
       name: 'c',
       a: a
    };
});

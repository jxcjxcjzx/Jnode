define(['a', 'exports'], function (a, exports) {
    exports.name = 'c';
    exports.a = a;
});

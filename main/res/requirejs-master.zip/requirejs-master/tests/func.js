define("func",
    function () {
        return function () {
            return "You called a function";
        }
    }
);

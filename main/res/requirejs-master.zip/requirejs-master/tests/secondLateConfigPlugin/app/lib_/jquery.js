var jQuery = {
		noConflict: function() {
			return jQuery;
		}
	},
	$ = jQuery;
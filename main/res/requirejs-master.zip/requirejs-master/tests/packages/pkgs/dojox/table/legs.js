define({
    name: 'dojox/table/legs'
});

define({
    name: 'dojox/door'
});

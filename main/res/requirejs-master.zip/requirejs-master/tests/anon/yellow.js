define("yellow", {
    name: "yellow"
});

define(function (require) {
    return {
        isBrowser: require.isBrowser
    };
});

$.fn.alpha = function() {
    return "alpha";
};
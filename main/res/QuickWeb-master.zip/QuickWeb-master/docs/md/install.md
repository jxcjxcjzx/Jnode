安装QuickWeb模块
=============

1.  ## 通过npm来安装
  在命令行下运行以下命令：**npm install quickweb**
    
2.  ## 下载源代码来安装
  +  打开[QuickWeb项目](https://github.com/leizongmin/QuickWeb)地址https://github.com/leizongmin/QuickWeb
     下载其源码
     
  +  安装依赖模块： **npm install formidable ejs should mocha mkdirp**
  

验证安装是否成功
============

在命令行中运行以下命令：**quickweb -help**
此时屏幕会打印出quickweb命令的使用方法，则表示安装成功。

![help](images/5.png)
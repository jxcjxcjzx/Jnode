#FASTA Grammar

# Summary

An ANTLR4 grammar for [FASTA](http://en.wikipedia.org/wiki/FASTA_format) files.

You can download appropriate example files at 

`ftp://ftp.ncbi.nih.gov/genomes/`





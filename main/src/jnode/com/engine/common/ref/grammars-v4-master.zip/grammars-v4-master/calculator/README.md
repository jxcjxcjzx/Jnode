# Calculator Grammar

# Summary

A simple ANTLR4 calculator grammar based on the khubla.com arithmetic grammar.  Calculator expands on arithmetic by adding functions, such as sin() and ln()

The calculator example is intended of an example of how to parse geometric and algebraic expressions with ANTLR



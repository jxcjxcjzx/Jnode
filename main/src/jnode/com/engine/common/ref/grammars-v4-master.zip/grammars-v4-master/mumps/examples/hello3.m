hello(who)
  write "Hello ",who,!
  quit

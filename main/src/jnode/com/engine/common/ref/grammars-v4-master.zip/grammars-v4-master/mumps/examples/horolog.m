horolog()
MYLABEL ; This is a comment
 WRITE !,"Hello World"
 WRITE !,$HOROLOG
 QUIT

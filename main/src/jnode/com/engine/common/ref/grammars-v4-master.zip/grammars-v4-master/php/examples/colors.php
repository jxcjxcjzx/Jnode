<?php



    $FavoriteColor = "green";



    if ($FavoriteColor == "blue") {



    print ("I like blue too!");



    } elseif ($FavoriteColor = green) {



    print ("MMMmmmmmmmmmm, green!");



    }



    ?>

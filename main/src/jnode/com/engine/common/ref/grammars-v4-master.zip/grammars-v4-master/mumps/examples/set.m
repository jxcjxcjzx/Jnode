xxxx()
  set x="hello"

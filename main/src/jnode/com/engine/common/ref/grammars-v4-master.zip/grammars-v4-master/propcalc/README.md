# Propositional Calculus Grammar

# Summary

A simple ANTLR4 propositional calculus grammar



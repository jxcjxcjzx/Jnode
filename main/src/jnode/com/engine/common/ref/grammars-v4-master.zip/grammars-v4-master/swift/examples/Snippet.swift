// var b = i < 2.0 error is on the 2.0

var b = i

class T {
	func foo() {
		for var i:CGFloat = 0; i < 2.0 + self.frame.size.width / ( groundTexture.size().width * 2.0 ); ++i {
			var sprite = SKSpriteNode(texture: groundTexture)
		}
	}
}

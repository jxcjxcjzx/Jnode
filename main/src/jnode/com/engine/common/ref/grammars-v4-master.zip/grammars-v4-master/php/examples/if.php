<?
if ($a > $b)
  echo "a is bigger than b";
?>

<?

static $a1 = 12;
static $a2 = 12.0;
static $a3 = 12.0 e 13.0;
static $a4 = 12.0 e 2;
$a5 = false;
$a6 = 0X13;
$a7 = 08;
?>
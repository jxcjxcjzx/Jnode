# MySQL parser

An ANTLR4 grammar for MySQL based on version 5.6 of 
http://dev.mysql.com/doc/refman/5.6/en/

math()
 write (1+2)*3

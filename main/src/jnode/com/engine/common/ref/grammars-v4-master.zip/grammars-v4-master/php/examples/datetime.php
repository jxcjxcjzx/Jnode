<head>
<?
 print(Date("l F d, Y"));
?>
</head>
<body>
<?
 print("hi");
?>

This is body text

</body>




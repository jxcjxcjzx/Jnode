hello()	
  write "Hello, World!",!
  quit

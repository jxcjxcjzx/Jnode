This ANTLR 4 C# grammar is based on the C# ANTLR 3 grammar from 
[ChristianWulf/CSharpGrammar] (https://github.com/ChristianWulf/CSharpGrammar)

Christian licenses that project with the Eclipse Public License, so for simplicity
my changes are offered under that license too.

License
---
Eclipse Public License - v 1.0 (http://www.eclipse.org/legal/epl-v10.html)


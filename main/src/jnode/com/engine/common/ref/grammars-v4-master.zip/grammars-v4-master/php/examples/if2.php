<?php

if ( $status_obj->publics  ) {
}
?>
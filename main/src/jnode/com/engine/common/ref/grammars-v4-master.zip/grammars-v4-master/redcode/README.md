#RedCode Grammar

# Summary

An ANTLR4 grammar for [RedCode](http://en.wikipedia.org/wiki/Core_War)

Grammar is based upon the published grammar [iwcs94](http://www.koth.org/info/icws94.html)






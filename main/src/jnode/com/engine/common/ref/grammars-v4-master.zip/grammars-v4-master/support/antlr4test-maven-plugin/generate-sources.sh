# run this script to generate the sources in order to be able to run the tests
mvn -f AntlrMojo-pom.xml clean antlr4:antlr4


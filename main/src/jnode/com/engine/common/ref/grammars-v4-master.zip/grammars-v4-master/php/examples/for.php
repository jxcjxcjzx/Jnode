<?
for ($j=0; $j<=10; $j++)
  {
  echo "The number is: $j <br>";
  } 
 ?> 
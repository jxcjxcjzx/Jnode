#MPS Grammar

# Summary

An ANTLR4 grammar for [MPS](https://en.wikipedia.org/wiki/MPS_(format) files.








